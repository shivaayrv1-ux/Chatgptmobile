@rem Gradle startup script for Windows
java -jar gradle\wrapper\gradle-wrapper.jar %*
